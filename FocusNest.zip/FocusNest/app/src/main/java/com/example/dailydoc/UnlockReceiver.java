package com.example.dailydoc;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class UnlockReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {

        if (intent.getAction() != null &&
                intent.getAction().equals(Intent.ACTION_USER_PRESENT)) {

            // When user unlocks, restart FocusActivity in pinned mode
            Intent i = new Intent(context, FocusActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                    | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT
                    | Intent.FLAG_ACTIVITY_NO_ANIMATION);
            i.putExtra("repin", true); // tell Activity to re-pin
            context.startActivity(i);
        }
    }
}
