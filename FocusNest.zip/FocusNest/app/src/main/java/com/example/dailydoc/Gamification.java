package com.example.dailydoc;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class Gamification {
    public static final String PREFS = "dailydoc_prefs";
    public static final String KEY_POINTS = "points";
    public static final String KEY_LEVEL = "level";
    public static final String KEY_STREAK = "streak";
    public static final String KEY_LAST_DATE = "last_focus_date";
    public static final String KEY_HISTORY = "history_json"; // JSONArray of session records
    public static final String KEY_DAILY_CHALLENGE = "daily_challenge"; // minutes target
    public static final String KEY_DAILY_COMPLETED = "daily_completed"; // yyyy-MM-dd -> boolean stored as string

    // Award points equal to minutes
    public static int awardPoints(Context ctx, int minutes) {
        SharedPreferences prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        int old = prefs.getInt(KEY_POINTS, 0);
        int add = Math.max(0, minutes);
        int now = old + add;
        prefs.edit().putInt(KEY_POINTS, now).apply();
        updateLevelIfNeeded(ctx, now);
        return add;
    }

    // basic level formula: level increases every 100 points
    public static void updateLevelIfNeeded(Context ctx, int totalPoints) {
        SharedPreferences prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        int level = prefs.getInt(KEY_LEVEL, 1);
        int newLevel = totalPoints / 100 + 1;
        if (newLevel != level) {
            prefs.edit().putInt(KEY_LEVEL, newLevel).apply();
        }
    }

    public static int getPoints(Context ctx) {
        return ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getInt(KEY_POINTS, 0);
    }

    public static int getLevel(Context ctx) {
        return ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getInt(KEY_LEVEL, 1);
    }

    // Streak: increments if last focus was yesterday or today; resets otherwise
    public static void updateStreak(Context ctx) {
        SharedPreferences prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String last = prefs.getString(KEY_LAST_DATE, "");
        String today = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
        int streak = prefs.getInt(KEY_STREAK, 0);

        if (last.equals(today)) {
            // already updated today; do nothing
            return;
        }

        if (!last.isEmpty() && wasYesterday(last)) {
            streak += 1;
        } else {
            streak = 1; // new streak
        }

        prefs.edit().putInt(KEY_STREAK, streak).putString(KEY_LAST_DATE, today).apply();
    }

    private static boolean wasYesterday(String lastDate) {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
            Date last = sdf.parse(lastDate);
            Date today = new Date();
            long diff = today.getTime() - last.getTime();
            long oneDay = 1000L * 60 * 60 * 24;
            return diff >= oneDay - 1000L && diff < (2 * oneDay);
        } catch (Exception e) {
            return false;
        }
    }

    // Save session history: {minutes: N, timestamp: yyyy-MM-dd HH:mm}
    public static void saveSessionHistory(Context ctx, int minutes) {
        try {
            SharedPreferences prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
            String raw = prefs.getString(KEY_HISTORY, "[]");
            JSONArray arr = new JSONArray(raw);
            JSONObject rec = new JSONObject();
            String when = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(new Date());
            rec.put("minutes", minutes);
            rec.put("when", when);
            arr.put(rec);
            prefs.edit().putString(KEY_HISTORY, arr.toString()).apply();
        } catch (Exception ignored) {}
    }

    // Simple daily challenge assignment (if not present, set to 25)
    public static int getDailyChallenge(Context ctx) {
        SharedPreferences prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        int target = prefs.getInt(KEY_DAILY_CHALLENGE, -1);
        if (target == -1) {
            target = 25;
            prefs.edit().putInt(KEY_DAILY_CHALLENGE, target).apply();
        }
        return target;
    }

    public static void markDailyCompleted(Context ctx) {
        SharedPreferences prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String today = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
        prefs.edit().putBoolean(KEY_DAILY_COMPLETED + "_" + today, true).apply();
    }

    public static boolean isDailyCompleted(Context ctx) {
        SharedPreferences prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String today = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
        return prefs.getBoolean(KEY_DAILY_COMPLETED + "_" + today, false);
    }
}
