package com.example.dailydoc;
import android.provider.Settings;
import android.net.Uri;

import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.InputType;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class HomeActivity extends AppCompatActivity {

    private TextView tvHello;
    private FloatingActionButton fabAdd;
    private Button btnChangePassword, btnViewHistory,btnViewRewards;
    public static final String PREFS = "dailydoc_prefs";
    public static final String KEY_USERNAME = "username";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        tvHello = findViewById(R.id.tvHello);
        fabAdd = findViewById(R.id.fabAdd);
        btnChangePassword = findViewById(R.id.btnChangePassword);
        btnViewHistory = findViewById(R.id.btnViewHistory);
        btnViewRewards=findViewById(R.id.btnViewRewards);
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        String name = prefs.getString(KEY_USERNAME, "User");
        tvHello.setText("Hello, " + name);


        fabAdd.setOnClickListener(v -> showTaskOptions());

        btnChangePassword.setOnClickListener(v -> startActivity(new Intent(HomeActivity.this, ChangePasswordActivity.class)));
        btnViewRewards.setOnClickListener(v -> {
            startActivity(new Intent(HomeActivity.this, RewardsActivity.class));
        });
        btnViewHistory.setOnClickListener(v -> {
            // Replace with your HistoryActivity if exists
            try {
                startActivity(new Intent(HomeActivity.this, HistoryActivity.class));
            } catch (Exception e) {
                Toast.makeText(this, "History not available", Toast.LENGTH_SHORT).show();
            }
        });
        if (!Settings.canDrawOverlays(this)) {
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivity(intent);
        }





    }


    private void showTaskOptions() {
        final String[] items = {"Start Focus Now", "Start Focus Later"};
        new AlertDialog.Builder(this)
                .setTitle("Add Task")
                .setItems(items, (dialog, which) -> {
                    if (which == 0) askForDurationAndStartNow();
                    else askForDelayThenSchedule();
                })
                .show();
    }

    private void askForDurationAndStartNow() {
        final EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_NUMBER);
        input.setHint("Duration in minutes");

        new AlertDialog.Builder(this)
                .setTitle("Start Now")
                .setMessage("Enter focus duration in minutes")
                .setView(input)
                .setPositiveButton("Start", (d, w) -> {
                    String s = input.getText() != null ? input.getText().toString().trim() : "";
                    if (s.isEmpty()) {
                        Toast.makeText(this, "Enter minutes", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    int minutes = Integer.parseInt(s);
                    long durationMs = minutes * 60L * 1000L;
                    Intent i = new Intent(HomeActivity.this, FocusActivity.class);
                    i.putExtra("duration", durationMs);
                    i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(i);
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void askForDelayThenSchedule() {
        final EditText delayInput = new EditText(this);
        delayInput.setInputType(InputType.TYPE_CLASS_NUMBER);
        delayInput.setHint("Delay (minutes) before focus starts");

        final EditText durationInput = new EditText(this);
        durationInput.setInputType(InputType.TYPE_CLASS_NUMBER);
        durationInput.setHint("Focus duration (minutes)");

        androidx.appcompat.widget.LinearLayoutCompat layout = new androidx.appcompat.widget.LinearLayoutCompat(this);
        layout.setOrientation(androidx.appcompat.widget.LinearLayoutCompat.VERTICAL);
        layout.setPadding(20, 10, 20, 10);
        layout.addView(delayInput);
        layout.addView(durationInput);

        new AlertDialog.Builder(this)
                .setTitle("Start Later")
                .setMessage("Enter delay and duration in minutes")
                .setView(layout)
                .setPositiveButton("Schedule", (d, w) -> {
                    String ds = delayInput.getText() != null ? delayInput.getText().toString().trim() : "";
                    String dur = durationInput.getText() != null ? durationInput.getText().toString().trim() : "";
                    if (ds.isEmpty() || dur.isEmpty()) {
                        Toast.makeText(this, "Enter both delay and duration", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    int delayMin = Integer.parseInt(ds);
                    int durationMin = Integer.parseInt(dur);
                    scheduleFocusAfter(delayMin, durationMin);
                    Toast.makeText(this, "Focus scheduled in " + delayMin + " minutes", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void scheduleFocusAfter(int delayMinutes, int durationMinutes) {
        long delayMs = delayMinutes * 60L * 1000L;
        long durationMs = durationMinutes * 60L * 1000L;

        StartFocusScheduler.schedule(this, delayMs, durationMs);
    }
}
