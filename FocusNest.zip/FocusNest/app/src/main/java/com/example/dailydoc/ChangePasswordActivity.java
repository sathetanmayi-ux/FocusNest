package com.example.dailydoc;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class ChangePasswordActivity extends AppCompatActivity {

    public static final String PREFS = "dailydoc_prefs";
    public static final String KEY_PASSWORD = "password";

    private EditText etOld, etNew, etConfirm;
    private Button btnChange;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_password);

        etOld = findViewById(R.id.etOld);
        etNew = findViewById(R.id.etNew);
        etConfirm = findViewById(R.id.etConfirm);
        btnChange = findViewById(R.id.btnChange);

        btnChange.setOnClickListener(v -> {
            SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
            String saved = prefs.getString(KEY_PASSWORD, "");
            String oldp = etOld.getText() != null ? etOld.getText().toString() : "";
            String newp = etNew.getText() != null ? etNew.getText().toString() : "";
            String conf = etConfirm.getText() != null ? etConfirm.getText().toString() : "";

            if (TextUtils.isEmpty(oldp) || TextUtils.isEmpty(newp) || TextUtils.isEmpty(conf)) {
                Toast.makeText(this, "Fill all fields", Toast.LENGTH_SHORT).show();
                return;
            }
            if (!oldp.equals(saved)) {
                Toast.makeText(this, "Old password incorrect", Toast.LENGTH_SHORT).show();
                return;
            }
            if (!newp.equals(conf)) {
                Toast.makeText(this, "New passwords do not match", Toast.LENGTH_SHORT).show();
                return;
            }
            prefs.edit().putString(KEY_PASSWORD, newp).apply();
            Toast.makeText(this, "Password changed", Toast.LENGTH_SHORT).show();
            finish();
        });
    }
}
