package com.example.dailydoc;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

public class HistoryAdapter extends BaseAdapter {
    Context ctx;
    ArrayList<SessionItem> data;

    public HistoryAdapter(Context ctx, ArrayList<SessionItem> data) {
        this.ctx = ctx;
        this.data = data;
    }

    @Override
    public int getCount() { return data.size(); }

    @Override
    public Object getItem(int position) { return data.get(position); }

    @Override
    public long getItemId(int position) { return data.get(position).id; }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        SessionItem item = data.get(position);
        if (convertView == null) {
            convertView = LayoutInflater.from(ctx).inflate(R.layout.item_session, parent, false);
        }
        TextView tvDuration = convertView.findViewById(R.id.tvDuration);
        TextView tvTimestamp = convertView.findViewById(R.id.tvTimestamp);

        long seconds = item.seconds;
        String dur = String.format("%02d:%02d", TimeUnit.SECONDS.toMinutes(seconds), seconds % 60);
        tvDuration.setText(dur);
        tvTimestamp.setText(item.timestamp);
        return convertView;
    }
}
