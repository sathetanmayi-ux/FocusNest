package com.example.dailydoc;

import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONObject;

public class RewardsActivity extends AppCompatActivity {

    private TextView tvPoints, tvLevel, tvStreak, tvChallenge;
    private LinearLayout llBadges, llHistory;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rewards);

        tvPoints = findViewById(R.id.tvPoints);
        tvLevel = findViewById(R.id.tvLevel);
        tvStreak = findViewById(R.id.tvStreak);
        tvChallenge = findViewById(R.id.tvChallenge);
        llBadges = findViewById(R.id.llBadges);
        llHistory = findViewById(R.id.llHistory);

        SharedPreferences prefs = getSharedPreferences(Gamification.PREFS, MODE_PRIVATE);
        int points = prefs.getInt(Gamification.KEY_POINTS, 0);
        int level = prefs.getInt(Gamification.KEY_LEVEL, 1);
        int streak = prefs.getInt(Gamification.KEY_STREAK, 0);

        tvPoints.setText("Points: " + points);
        tvLevel.setText("Level: " + level);
        tvStreak.setText("Streak: " + streak + " days");

        int challenge = Gamification.getDailyChallenge(this);
        boolean done = Gamification.isDailyCompleted(this);
        tvChallenge.setText("Daily challenge: " + challenge + " mins — " + (done ? "Completed" : "Pending"));

        llBadges.removeAllViews();
        addBadgeIf(points >= 100, "#CD7F32", "Bronze Focuser (100 pts)");   // Bronze
        addBadgeIf(points >= 300, "#C0C0C0", "Silver Focuser (300 pts)");   // Silver
        addBadgeIf(points >= 700, "#FFD700", "Gold Focuser (700 pts)");     // Gold
        addBadgeIf(points >= 1500, "#6A0DAD", "Focus Master (1500 pts)");   // Purple

        llHistory.removeAllViews();
        try {
            String raw = prefs.getString(Gamification.KEY_HISTORY, "[]");
            JSONArray arr = new JSONArray(raw);

            for (int i = arr.length() - 1; i >= 0; i--) {
                JSONObject rec = arr.getJSONObject(i);
                String when = rec.getString("when");
                int mins = rec.getInt("minutes");

                TextView tv = new TextView(this);
                tv.setText(when + " — " + mins + " min");
                tv.setPadding(12, 12, 12, 12);
                tv.setBackgroundColor(Color.parseColor("#222222"));
                tv.setTextColor(Color.WHITE);
                tv.setTextSize(15);

                LinearLayout.LayoutParams params =
                        new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,
                                LinearLayout.LayoutParams.WRAP_CONTENT);
                params.setMargins(0, 10, 0, 0);

                llHistory.addView(tv, params);
            }
        } catch (Exception ignored) {}
    }

    private void addBadgeIf(boolean cond, String colorHex, String label) {
        if (!cond) return;

        TextView box = new TextView(this);
        box.setText(label);
        box.setTextColor(Color.WHITE);
        box.setPadding(20, 20, 20, 20);
        box.setTextSize(16);
        box.setBackgroundColor(Color.parseColor(colorHex));

        LinearLayout.LayoutParams params =
                new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT);
        params.setMargins(0, 12, 0, 0);

        llBadges.addView(box, params);
    }
}
