package com.example.dailydoc;

import android.os.Bundle;
import android.widget.ListView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

public class HistoryActivity extends AppCompatActivity {

    ListView listView;
    DatabaseHelper db;
    HistoryAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);
        listView = findViewById(R.id.listView);
        db = new DatabaseHelper(this);
        ArrayList<SessionItem> data = db.getAllSessions();
        adapter = new HistoryAdapter(this, data);
        listView.setAdapter(adapter);
    }
}
