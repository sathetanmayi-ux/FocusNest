package com.example.dailydoc;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class StartFocusReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {

        long duration = intent.getLongExtra("duration", 1500000);

        Intent service = new Intent(context, FocusStartService.class);
        service.putExtra("duration", duration);

        context.startForegroundService(service);
    }
}
