package com.example.dailydoc;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;

public class DatabaseHelper extends SQLiteOpenHelper {

    public static final String DB_NAME = "dailydoc.db";
    public static final int DB_VER = 1;

    public DatabaseHelper(Context ctx) {
        super(ctx, DB_NAME, null, DB_VER);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String create = "CREATE TABLE sessions (id INTEGER PRIMARY KEY AUTOINCREMENT, seconds INTEGER, timestamp DATETIME DEFAULT CURRENT_TIMESTAMP)";
        db.execSQL(create);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldV, int newV) {
        db.execSQL("DROP TABLE IF EXISTS sessions");
        onCreate(db);
    }

    public long insertSession(long seconds) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("seconds", seconds);
        long id = db.insert("sessions", null, cv);
        db.close();
        return id;
    }

    public ArrayList<SessionItem> getAllSessions() {
        ArrayList<SessionItem> list = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.rawQuery("SELECT id, seconds, timestamp FROM sessions ORDER BY timestamp DESC", null);
        while (c.moveToNext()) {
            int id = c.getInt(0);
            long seconds = c.getLong(1);
            String ts = c.getString(2);
            list.add(new SessionItem(id, seconds, ts));
        }
        c.close();
        db.close();
        return list;
    }
}
