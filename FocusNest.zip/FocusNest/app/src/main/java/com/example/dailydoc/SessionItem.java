package com.example.dailydoc;

public class SessionItem {
    public int id;
    public long seconds;
    public String timestamp;

    public SessionItem(int id, long seconds, String timestamp) {
        this.id = id;
        this.seconds = seconds;
        this.timestamp = timestamp;
    }
}
