package com.example.dailydoc;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;

public class FocusStartService extends Service {

    private static final String CHANNEL_ID = "focus_start_channel";

    @Override
    public void onCreate() {
        super.onCreate();
        createChannel();
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel nc = new NotificationChannel(
                    CHANNEL_ID,
                    "DailyDoc Focus Start",
                    NotificationManager.IMPORTANCE_LOW
            );
            NotificationManager nm = getSystemService(NotificationManager.class);
            nm.createNotificationChannel(nc);
        }
    }

    @Override

    public int onStartCommand(Intent intent, int flags, int startId) {

        long duration = intent.getLongExtra("duration", 1500000);

        // Start minimal foreground notification
        Notification n = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("FocusNest")
                .setContentText("Preparing focus session…")
                .setSmallIcon(R.mipmap.ic_launcher)
                .setOngoing(true)
                .build();

        startForeground(2, n);

        // ⭐ Start overlay service instead of opening activity directly
        Intent overlay = new Intent(this, OverlayService.class);
        overlay.putExtra("duration", duration);
        startService(overlay);

        stopSelf();
        return START_NOT_STICKY;
    }


    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
