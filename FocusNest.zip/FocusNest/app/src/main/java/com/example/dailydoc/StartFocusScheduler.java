package com.example.dailydoc;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.SystemClock;

public class StartFocusScheduler {

    public static void schedule(Context context, long delayMs, long durationMs) {

        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);

        Intent intent = new Intent("com.example.dailydoc.START_FOCUS");
        intent.setClass(context, StartFocusReceiver.class);
        intent.putExtra("duration", durationMs);

        PendingIntent pi = PendingIntent.getBroadcast(
                context,
                1001,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        long trigger = SystemClock.elapsedRealtime() + delayMs;

        am.setExactAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, trigger, pi);
    }
}
