package com.example.dailydoc;

import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class FocusActivity extends AppCompatActivity {

    private TextView tvTimer;
    private com.google.android.material.progressindicator.CircularProgressIndicator progressBar;
    private Button btnEmergencyStop;
    private CountDownTimer timer;
    private boolean isLocked = false;
    private long totalMillis;
    private int lastShownMinute = -1; // for motivational toasts

    public static final String PREFS = "dailydoc_prefs";
    public static final String KEY_PASSWORD = "password";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // keep screen on & fullscreen
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        setContentView(R.layout.activity_focus);

        tvTimer = findViewById(R.id.tvTimer);
        progressBar = findViewById(R.id.progressCircular);
        btnEmergencyStop = findViewById(R.id.btnEmergencyStop);

        long durationMs = getIntent().getLongExtra("duration", 25 * 60 * 1000L);
        totalMillis = durationMs;

        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                if (isLocked) {
                    Toast.makeText(FocusActivity.this, "Back disabled during focus mode", Toast.LENGTH_SHORT).show();
                } else {
                    setEnabled(false);
                    FocusActivity.super.onBackPressed();
                }
            }
        });

        startFocusTimer(durationMs);

        btnEmergencyStop.setOnClickListener(v -> promptPasswordAndStop());
    }

    private void startFocusTimer(long millis) {
        if (isLocked) return;
        isLocked = true;
        totalMillis = millis;

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            try {
                startLockTask();
                Toast.makeText(this, "Screen pinned — Focus Mode started!", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Toast.makeText(this, "Enable Screen Pinning in Settings", Toast.LENGTH_LONG).show();
            }
        }

        progressBar.setMax(100);
        progressBar.setProgress(0);

        timer = new CountDownTimer(millis, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                long totalSeconds = millisUntilFinished / 1000;
                long minutes = totalSeconds / 60;
                long seconds = totalSeconds % 60;
                tvTimer.setText(String.format("%02d:%02d", minutes, seconds));
                int progress = (int) (100 * (1 - (float) millisUntilFinished / totalMillis));
                progressBar.setProgress(progress);

                // motivational toast every 5 minutes (and at 1 minute left)
                int elapsedMinutes = (int)((totalMillis - millisUntilFinished) / 60000);
                if ((elapsedMinutes > 0 && elapsedMinutes % 5 == 0 && lastShownMinute != elapsedMinutes) ||
                        (minutes == 0 && seconds == 60)) {
                    showMotivationalToast();
                    lastShownMinute = elapsedMinutes;
                }
            }

            @Override
            public void onFinish() {
                // award points, update streak, history, daily challenge
                int minutes = (int) (totalMillis / 60000);
                int points = Gamification.awardPoints(FocusActivity.this, minutes);
                Gamification.updateStreak(FocusActivity.this);
                Gamification.saveSessionHistory(FocusActivity.this, minutes);

                if (!Gamification.isDailyCompleted(FocusActivity.this)) {
                    int challenge = Gamification.getDailyChallenge(FocusActivity.this);
                    if (minutes >= challenge) {
                        Gamification.markDailyCompleted(FocusActivity.this);
                    }
                }

                isLocked = false;
                try {
                    stopLockTask();
                } catch (Exception ignored) {}
                // show congratulations dialog with earned points and badges
                showCompletionDialog(points);
            }
        }.start();
    }

    private void showMotivationalToast() {
        String[] msgs = new String[]{
                "Stay sharp — you’re doing great!",
                "Focus is your superpower.",
                "Keep going, progress is happening.",
                "You're closer than you think.",
                "One minute at a time!"
        };
        int idx = (int) (Math.random() * msgs.length);
        Toast.makeText(this, msgs[idx], Toast.LENGTH_SHORT).show();
    }

    private void showCompletionDialog(int pointsEarned) {
        int total = Gamification.getPoints(FocusActivity.this);
        int level = Gamification.getLevel(FocusActivity.this);
        int streak = getSharedPreferences(Gamification.PREFS, MODE_PRIVATE).getInt(Gamification.KEY_STREAK, 0);

        String message = "You earned " + pointsEarned + " points!\nTotal: " + total +
                "\nLevel: " + level + "\nStreak: " + streak + " days";

        new AlertDialog.Builder(this)
                .setTitle("Great Job!")
                .setMessage(message)
                .setPositiveButton("OK", (d, w) -> finishAndReturnHome())
                .setNeutralButton("View Rewards", (d, w) -> {
                    finish();
                    Intent i = new Intent(FocusActivity.this, RewardsActivity.class);
                    startActivity(i);
                })
                .show();
    }

    private void promptPasswordAndStop() {
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        String savedPass = prefs.getString(KEY_PASSWORD, "");

        final EditText input = new EditText(this);
        input.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD);

        new AlertDialog.Builder(this)
                .setTitle("Emergency Stop")
                .setMessage("Enter password to stop focus mode")
                .setView(input)
                .setPositiveButton("Stop", (dialog, which) -> {
                    String entered = input.getText() != null ? input.getText().toString() : "";
                    if (entered.equals(savedPass)) {
                        if (timer != null) timer.cancel();
                        try { stopLockTask(); } catch (Exception ignored) {}
                        Toast.makeText(FocusActivity.this, "Emergency stop successful", Toast.LENGTH_SHORT).show();
                        finishAndReturnHome();
                    } else {
                        Toast.makeText(FocusActivity.this, "Incorrect password", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void finishAndReturnHome() {
        finish();
        Intent i = new Intent(FocusActivity.this, HomeActivity.class);
        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(i);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (timer != null) timer.cancel();
        try { stopLockTask(); } catch (Exception ignored) {}
    }
    @Override
    protected void onResume() {
        super.onResume();

        boolean shouldRepin = getIntent().getBooleanExtra("repin", false);

        if (shouldRepin) {
            getIntent().removeExtra("repin"); // avoid infinite loop
            startLockTask(); // re-enable screen pinning
        }
    }


    private boolean isInLockTaskMode() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            ActivityManager am = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
            int mode = am.getLockTaskModeState();
            return mode != ActivityManager.LOCK_TASK_MODE_NONE;
        }
        return false;
    }
}
