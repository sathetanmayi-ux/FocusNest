package com.example.dailydoc;

import android.app.Service;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.IBinder;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;

import androidx.annotation.Nullable;

public class OverlayService extends Service {

    private WindowManager windowManager;
    private View overlayView;

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {

        long duration = intent.getLongExtra("duration", 1500000);

        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);

        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_FULLSCREEN
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
                PixelFormat.TRANSLUCENT
        );

        params.gravity = Gravity.CENTER;

        overlayView = LayoutInflater.from(this)
                .inflate(R.layout.overlay_window, null);

        windowManager.addView(overlayView, params);

        // After 300ms → launch FocusActivity on top
        overlayView.postDelayed(() -> {
            Intent focus = new Intent(this, FocusActivity.class);
            focus.putExtra("duration", duration);
            focus.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(focus);

            // Remove overlay
            windowManager.removeView(overlayView);
            stopSelf();

        }, 300);

        return START_NOT_STICKY;
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
