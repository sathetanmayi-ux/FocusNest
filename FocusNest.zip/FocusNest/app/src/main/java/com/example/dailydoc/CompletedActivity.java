package com.example.dailydoc;

import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class CompletedActivity extends AppCompatActivity {

    Button btnOk;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_completed);
        btnOk = findViewById(R.id.btnOk);
        btnOk.setOnClickListener(v -> finish());
    }
}
